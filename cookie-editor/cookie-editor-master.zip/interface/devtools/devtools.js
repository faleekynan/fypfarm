chrome.devtools.panels.create("Cookie Editor",
    "/icons/cookie-filled-small.svg",
    "/interface/devtools/cookie-list.html",
    function(panel) {

});
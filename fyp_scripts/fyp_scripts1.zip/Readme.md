Example Chrome Extension

This example chrome extension is only a template for other one. All it does in its current form is to make the background of any site blue, you don't want that ;)

You'll need to run `bower install` for jQuery to be loaded, or add that file manually.
